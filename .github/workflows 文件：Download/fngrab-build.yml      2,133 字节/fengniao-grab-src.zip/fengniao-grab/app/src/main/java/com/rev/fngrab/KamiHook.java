package com.rev.fngrab;

import java.lang.reflect.Method;
import java.util.HashSet;
import java.util.Set;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * 卡密旁路：接管 com.aaa.*（战神头盔融合版 / YunKami）
 * 思路：
 *  1) hook ClassLoader.loadClass，凡是 com.aaa.* 的类一加载就挂上
 *  2) 该类所有方法写日志（名字 + 参数 + 返回值）
 *  3) 返回 boolean 的方法强制返回 true（授权判定的典型形态）
 *  4) 额外 hook 签名校验 / Toast，捕捉授权失败提示
 */
public class KamiHook {

    private static final String TAG = "FNKAMI";
    private static final Set<String> HOOKED = new HashSet<>();

    public static void install(ClassLoader cl) {
        try {
            XposedHelpers.findAndHookMethod(ClassLoader.class, "loadClass", String.class,
                    new XC_MethodHook() {
                        @Override protected void afterHookedMethod(MethodHookParam p) {
                            Object r = p.getResult();
                            if (!(r instanceof Class)) return;
                            Class<?> c = (Class<?>) r;
                            String n = c.getName();
                            if (!n.startsWith("com.aaa.")) return;
                            hookClass(c);
                        }
                    });
            XposedBridge.log(TAG + ": ClassLoader 监听已装");
        } catch (Throwable e) {
            XposedBridge.log(TAG + ": loadClass hook 失败 " + e);
        }

        // 飞书：签名校验一律放行
        try {
            XposedHelpers.findAndHookMethod("java.security.Signature", cl, "verify", byte[].class,
                    new XC_MethodHook() {
                        @Override protected void beforeHookedMethod(MethodHookParam p) {
                            XposedBridge.log(TAG + ": Signature.verify 被调用 → 放行 true");
                            p.setResult(Boolean.TRUE);
                        }
                    });
        } catch (Throwable ignored) { }

        // 提示文字（授权失败通常弹 Toast）
        try {
            XposedHelpers.findAndHookMethod("android.widget.Toast", cl, "show",
                    new XC_MethodHook() {
                        @Override protected void afterHookedMethod(MethodHookParam p) {
                            try {
                                Object t = p.thisObject;
                                Object txt = XposedHelpers.callMethod(t, "getText");
                                XposedBridge.log(TAG + ": Toast = " + txt);
                            } catch (Throwable ignored) { }
                        }
                    });
        } catch (Throwable ignored) { }
    }

    private static void hookClass(final Class<?> c) {
        String name = c.getName();
        if (HOOKED.contains(name)) return;
        HOOKED.add(name);
        XposedBridge.log(TAG + ": 发现类 " + name);

        for (Method m : c.getDeclaredMethods()) {
            try {
                if (m.isSynthetic()) continue;
                final String sig = name + "#" + m.getName();
                final boolean retBool = m.getReturnType() == boolean.class;
                XposedBridge.hookMethod(m, new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        Object res = p.getResult();
                        XposedBridge.log(TAG + ": " + sig + " -> " + res);
                    }
                    @Override protected void beforeHookedMethod(MethodHookParam p) {
                        if (retBool) {
                            XposedBridge.log(TAG + ": 强制 true ← " + sig);
                            p.setResult(Boolean.TRUE);
                        }
                    }
                });
            } catch (Throwable ignored) { }
        }
    }
}
