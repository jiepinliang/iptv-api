package com.rev.fngrab;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;

public class SettingsActivity extends Activity {

    private SharedPreferences sp;
    private EditText etInterval, etKeyword, etMin, etMax;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_settings);
        sp = getSharedPreferences("cfg", MODE_PRIVATE);

        Switch sw = findViewById(R.id.sw_enable);
        etInterval = findViewById(R.id.et_interval);
        etKeyword  = findViewById(R.id.et_keyword);
        etMin      = findViewById(R.id.et_mindist);
        etMax      = findViewById(R.id.et_maxdist);

        sw.setChecked(sp.getBoolean("enable", true));
        etInterval.setText(String.valueOf(sp.getLong("interval", 300)));
        etKeyword.setText(sp.getString("keyword", "抢单"));
        etMin.setText(String.valueOf(sp.getInt("mindist", 0)));
        etMax.setText(String.valueOf(sp.getInt("maxdist", 2000)));

        sw.setOnCheckedChangeListener((v, c) -> sp.edit().putBoolean("enable", c).apply());

        etInterval.setOnFocusChangeListener((v, f) -> {
            if (!f) saveLong("interval", etInterval, 300);
        });
        etKeyword.setOnFocusChangeListener((v, f) -> {
            if (!f) sp.edit().putString("keyword", etKeyword.getText().toString()).apply();
        });
        etMin.setOnFocusChangeListener((v, f) -> {
            if (!f) saveInt("mindist", etMin, 0);
        });
        etMax.setOnFocusChangeListener((v, f) -> {
            if (!f) saveInt("maxdist", etMax, 2000);
        });

        bindPreset(R.id.btn_500,  500);
        bindPreset(R.id.btn_1000, 1000);
        bindPreset(R.id.btn_2000, 2000);
        bindPreset(R.id.btn_3000, 3000);
        bindPreset(R.id.btn_5000, 5000);
        bindPreset(R.id.btn_all,  0);      // 0 = 不限
    }

    private void saveInt(String key, EditText et, int def) {
        try {
            sp.edit().putInt(key, Integer.parseInt(et.getText().toString().trim())).apply();
        } catch (Exception e) {
            et.setText(String.valueOf(def));
        }
    }

    private void saveLong(String key, EditText et, long def) {
        try {
            sp.edit().putLong(key, Long.parseLong(et.getText().toString().trim())).apply();
        } catch (Exception e) {
            et.setText(String.valueOf(def));
        }
    }

    private void bindPreset(int id, final int meters) {
        Button btn = findViewById(id);
        btn.setOnClickListener(v -> {
            sp.edit().putInt("maxdist", meters).apply();
            etMax.setText(String.valueOf(meters));
        });
    }
}
