// 蜂鸟众包自动抢单（按取餐距离）— Frida 版，无需编译
// 用法: frida -H 127.0.0.1:27043 -f me.ele.crowdsource -l grab.js
var KEYWORD   = "抢单";
var MAX_DIST  = 2000;    // 最大取餐距离(米)，0=不限
var MIN_DIST  = 0;       // 最小取餐距离(米)，0=不限
var INTERVAL  = 300;
var DIST_RE   = /(\d+(?:\.\d+)?)\s*(km|KM|Km|公里|m|M|米)/;
var PICKUP_RE = /取餐[^\d]{0,10}(\d+(?:\.\d+)?)\s*(km|KM|Km|公里|m|M|米)/;

var lastClick = 0;
var currentActivity = null;

Java.perform(function () {
  var Activity = Java.use("android.app.Activity");
  Activity.onResume.implementation = function () {
    this.onResume();
    currentActivity = this;
  };
  setInterval(function () { try { scanAndGrab(); } catch (e) {} }, INTERVAL);
  console.log("[FNGrab] 启动 关键字=" + KEYWORD + " 最大距离=" + MAX_DIST + "m");
});

function meters(text) {
  var m = PICKUP_RE.exec(text || "") || DIST_RE.exec(text || "");
  if (!m) return -1;
  var v = parseFloat(m[1]);
  var u = m[2];
  return (u === "km" || u === "KM" || u === "Km" || u === "公里") ? Math.round(v * 1000) : Math.round(v);
}

function walk(node, out) {
  var ViewGroup = Java.use("android.view.ViewGroup");
  var TextView = Java.use("android.widget.TextView");
  var stack = [node], guard = 0;
  while (stack.length && guard++ < 2000) {
    var v = stack.shift();
    if (v === null) continue;
    if (TextView.class.isInstance(v)) out.push(v);
    if (ViewGroup.class.isInstance(v)) {
      var g = ViewGroup.cast(v);
      for (var i = 0; i < g.getChildCount(); i++) stack.push(g.getChildAt(i));
    }
  }
}

function scanAndGrab() {
  var act = currentActivity;
  if (act === null || (MAX_DIST === 0 && MIN_DIST === 0)) return;
  var now = Date.now();
  if (now - lastClick < INTERVAL) return;

  Java.perform(function () {
    var TextView = Java.use("android.widget.TextView");
    var View = Java.use("android.view.View");

    var all = [];
    walk(act.getWindow().getDecorView(), all);

    var cands = [];
    for (var i = 0; i < all.length; i++) {
      var t = all[i];
      var txt = t.getText() ? t.getText().toString() : "";
      var d = meters(txt);
      if (d >= 0 && t.isShown()) cands.push({ node: t, d: d });
    }
    if (cands.length === 0) return;
    cands.sort(function (a, b) { return a.d - b.d; });

    for (var k = 0; k < cands.length; k++) {
      var c = cands[k];
      if (MAX_DIST > 0 && c.d > MAX_DIST) break;
      if (MIN_DIST > 0 && c.d < MIN_DIST) continue;

      // 往上找同时包含距离和按钮的卡片
      var p = c.node, card = null;
      for (var depth = 0; depth < 10 && p !== null; depth++) {
        var texts = []; walk(p, texts);
        var hasBtn = false;
        for (var ti = 0; ti < texts.length; ti++) {
          var s2 = texts[ti].getText() ? texts[ti].getText().toString() : "";
          if (s2.indexOf(KEYWORD) >= 0 && texts[ti].isShown()) { hasBtn = true; break; }
        }
        if (hasBtn) { card = p; break; }
        var par = p.getParent();
        p = (par !== null && View.class.isInstance(par)) ? View.cast(par) : null;
      }
      if (card === null) continue;

      var texts2 = []; walk(card, texts2);
      for (var j = 0; j < texts2.length; j++) {
        var s3 = texts2[j].getText() ? texts2[j].getText().toString() : "";
        if (s3.indexOf(KEYWORD) < 0 || !texts2[j].isShown()) continue;
        var btn = texts2[j];
        for (var n = 0; n < 5 && btn !== null; n++) {
          if (btn.isClickable()) break;
          var pp = btn.getParent();
          btn = (pp !== null && View.class.isInstance(pp)) ? View.cast(pp) : null;
        }
        if (btn !== null && btn.isClickable()) {
          lastClick = now;
          console.log("[FNGrab] 抢 " + c.d + "m");
          btn.performClick();
          return;
        }
      }
    }
  });
}
