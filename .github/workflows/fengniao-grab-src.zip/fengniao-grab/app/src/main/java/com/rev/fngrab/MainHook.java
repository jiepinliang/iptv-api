package com.rev.fngrab;

import android.app.Activity;
import android.database.Cursor;
import android.net.Uri;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 蜂鸟众包自动抢单（按取餐距离区间过滤）
 *
 * 纯界面级：读卡片上的距离文本 → 按距离排序 → 只点区间内的最近一单。
 * 不 hook 内部接口，App 升级换类名也能用。
 */
public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "FNGrab";
    private static final String TARGET = "me.ele.crowdsource";

    /** 距离文本：1.2km / 800m / 1.5公里 / 300米 */
    private static final Pattern DIST = Pattern.compile(
            "(\\d+(?:\\.\\d+)?)\\s*(km|KM|Km|公里|m|M|米)");

    /** 优先取「取餐」后面的距离 */
    private static final Pattern PICKUP = Pattern.compile(
            "取餐[^\\d]{0,10}(\\d+(?:\\.\\d+)?)\\s*(km|KM|Km|公里|m|M|米)");

    private static volatile boolean enabled = true;
    private static volatile long minInterval = 300;
    private static volatile String keyword = "抢单";
    /** 最小取餐距离（米），0 = 不限下限 */
    private static volatile int minDistM = 0;
    /** 最大取餐距离（米），0 = 不限上限 */
    private static volatile int maxDistM = 2000;

    private static volatile Activity currentActivity;
    private static volatile long lastClick = 0;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (!TARGET.equals(lp.packageName)) return;
        XposedBridge.log(TAG + ": 注入 " + lp.packageName + " pid=" + android.os.Process.myPid());

        readPrefs(lp.classLoader);

        XposedHelpers.findAndHookMethod(Activity.class, "onResume", new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam p) {
                currentActivity = (Activity) p.thisObject;
            }
        });

        hookNotify(lp.classLoader, "me.ele.hb.biz.order.notify.LPDRefreshGrabOrderListNotification");
        hookNotify(lp.classLoader, "me.ele.hb.biz.order.notify.LPDEnableSlideGrabOrderNotification");

        Thread t = new Thread(new Runnable() {
            @Override public void run() {
                while (true) {
                    try {
                        Thread.sleep(Math.max(120, minInterval));
                        if (enabled && !(maxDistM == 0 && minDistM == 0)) scanAndGrab();
                    } catch (Throwable e) {
                        XposedBridge.log(TAG + ": 轮询异常 " + e);
                    }
                }
            }
        }, "fngrab-poll");
        t.setDaemon(true);
        t.start();
    }

    private void readPrefs(ClassLoader cl) {
        try {
            Class<?> helper = XposedHelpers.findClass("android.app.AndroidAppHelper", cl);
            Object app = XposedHelpers.callStaticMethod(helper, "currentApplication");
            if (app == null) return;
            Object resolver = XposedHelpers.callMethod(app, "getContentResolver");
            Cursor c = (Cursor) XposedHelpers.callMethod(resolver, "query",
                    Uri.parse("content://com.rev.fngrab.cfg"), null, null, null, null);
            if (c != null && c.moveToFirst()) {
                enabled = c.getInt(0) == 1;
                minInterval = c.getLong(1);
                keyword = c.getString(2);
                minDistM = c.getInt(3);
                maxDistM = c.getInt(4);
                c.close();
            }
            XposedBridge.log(TAG + ": 配置 enable=" + enabled + " interval=" + minInterval
                    + " keyword=" + keyword + " 区间=" + minDistM + "~" + maxDistM + "m");
        } catch (Throwable e) {
            XposedBridge.log(TAG + ": 读配置失败，用默认值 " + e);
        }
    }

    private void hookNotify(ClassLoader cl, String cls) {
        try {
            Class<?> c = XposedHelpers.findClass(cls, cl);
            XposedBridge.hookAllMethods(c, "onReceive", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    if (enabled && !(maxDistM == 0 && minDistM == 0)) scanAndGrab();
                }
            });
            XposedBridge.log(TAG + ": 已挂刷新通知 " + cls);
        } catch (Throwable ignored) {
            XposedBridge.log(TAG + ": 无此通知 " + cls);
        }
    }

    private void collectTexts(View root, List<TextView> out) {
        ArrayDeque<View> q = new ArrayDeque<>();
        q.add(root);
        int guard = 0;
        while (!q.isEmpty() && guard++ < 2000) {
            View v = q.poll();
            if (v == null) continue;
            if (v instanceof TextView) out.add((TextView) v);
            if (v instanceof ViewGroup) {
                ViewGroup g = (ViewGroup) v;
                for (int i = 0; i < g.getChildCount(); i++) q.add(g.getChildAt(i));
            }
        }
    }

    /** 解析距离文本 -> 米；有「取餐」字样优先取餐距离 */
    private int parseMeters(String s) {
        if (s == null) return -1;
        Matcher m = PICKUP.matcher(s);
        if (!m.find()) {
            m = DIST.matcher(s);
            if (!m.find()) return -1;
        }
        try {
            double v = Double.parseDouble(m.group(1));
            String u = m.group(2).toLowerCase();
            if (u.startsWith("k") || u.contains("公里")) return (int) (v * 1000);
            return (int) v;
        } catch (Throwable e) {
            return -1;
        }
    }

    /** 往上找同时包含「距离」和「抢单」按钮的卡片容器 */
    private View findCard(View node) {
        View p = node;
        for (int depth = 0; depth < 10 && p != null; depth++) {
            List<TextView> texts = new ArrayList<>();
            collectTexts(p, texts);
            boolean hasBtn = false;
            for (TextView t : texts) {
                CharSequence cs = t.getText();
                if (cs != null && cs.toString().contains(keyword) && t.isShown()) {
                    hasBtn = true;
                    break;
                }
            }
            if (hasBtn && p instanceof ViewGroup) return p;
            p = (p.getParent() instanceof View) ? (View) p.getParent() : null;
        }
        return null;
    }

    private View findGrabButton(View card) {
        List<TextView> texts = new ArrayList<>();
        collectTexts(card, texts);
        for (TextView t : texts) {
            CharSequence cs = t.getText();
            if (cs == null) continue;
            if (!cs.toString().contains(keyword)) continue;
            if (!t.isShown()) continue;
            View btn = t;
            for (int i = 0; i < 5 && btn != null; i++) {
                if (btn.isClickable()) return btn;
                btn = (btn.getParent() instanceof View) ? (View) btn.getParent() : null;
            }
            return t;
        }
        return null;
    }

    /** 核心：距离升序，抢区间内最近的一单 */
    private void scanAndGrab() {
        Activity act = currentActivity;
        if (act == null) return;
        long now = SystemClock.uptimeMillis();
        if (now - lastClick < minInterval) return;

        try {
            View root = act.getWindow().getDecorView();
            List<TextView> all = new ArrayList<>();
            collectTexts(root, all);

            final List<int[]> dists = new ArrayList<>();   // [米, 索引]
            List<TextView> distNodes = new ArrayList<>();
            for (TextView t : all) {
                CharSequence cs = t.getText();
                if (cs == null || !t.isShown()) continue;
                int m = parseMeters(cs.toString());
                if (m >= 0) {
                    distNodes.add(t);
                    dists.add(new int[]{m, dists.size()});
                }
            }
            if (dists.isEmpty()) return;

            Collections.sort(dists, new Comparator<int[]>() {
                @Override public int compare(int[] a, int[] b) { return a[0] - b[0]; }
            });

            for (int[] d : dists) {
                int meters = d[0];
                if (maxDistM > 0 && meters > maxDistM) break;      // 更远的不用看
                if (minDistM > 0 && meters < minDistM) continue;   // 太近的跳过
                View node = distNodes.get(d[1]);
                View card = findCard(node);
                if (card == null) continue;
                View btn = findGrabButton(card);
                if (btn == null) continue;
                lastClick = now;
                XposedBridge.log(TAG + ": 抢单 距离=" + meters + "m 区间="
                        + minDistM + "~" + maxDistM);
                btn.performClick();
                return;
            }
        } catch (Throwable e) {
            XposedBridge.log(TAG + ": 扫描异常 " + e);
        }
    }
}
