# 蜂鸟抢单助手（Xposed）

## 它做什么
监控蜂鸟众包抢单大厅的刷新，自动点击界面上带「抢单」字样的按钮。

## 为什么用「点按钮」而不是 hook 接口
- 接口路径 `/lpd_cs.delivery_query/v2/crowd/grab_center_orders` 会变，明文抢单接口还带签名
- 点按钮是在真实界面上操作，App 升级后大概率仍可用
- 只依赖 Android 的 View 树，不依赖混淆后的类名

## 构建（两种）

### A. 本地
```bash
cd fengniao-grab
./gradlew assembleRelease
# 产物: app/build/outputs/apk/release/app-release-unsigned.apk
```

### B. GitHub Actions（手机就能操作）
1. 把本目录推到自己的 GitHub 仓库
2. Actions → Build FNGrab APK → Run workflow
3. 跑完在下方的 Artifacts 下载 APK

## 安装
1. 安装 APK
2. LSPosed → 模块 → 启用「蜂鸟抢单助手」
3. 作用域勾选 `me.ele.crowdsource`
4. 强制停止蜂鸟后重新打开

## 配置
打开 App 可以设置：
- 启用/关闭
- 点击间隔（默认 300ms，别低于 200）
- 按钮关键字（默认「抢单」）

## 已知限制
- 只点「按钮」，不判断订单价格/距离，需要可在后续版本加过滤
- 界面结构改版后关键字要跟着改
- 频率过高会触发服务端风控，间隔别设太小
