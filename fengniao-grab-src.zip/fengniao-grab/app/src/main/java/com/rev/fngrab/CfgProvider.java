package com.rev.fngrab;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;

/**
 * 给被 hook 的进程读配置用。
 * 完全本地：只读本模块自己的 SharedPreferences，不联网。
 */
public class CfgProvider extends ContentProvider {
    public static final String AUTHORITY = "com.rev.fngrab.cfg";

    @Override public boolean onCreate() { return true; }

    @Override public Cursor query(Uri uri, String[] projection, String sel, String[] args, String sort) {
        SharedPreferences sp = getContext().getSharedPreferences("cfg", 0);
        MatrixCursor c = new MatrixCursor(new String[]{"enable", "interval", "keyword"});
        c.addRow(new Object[]{
                sp.getBoolean("enable", true) ? 1 : 0,
                sp.getLong("interval", 300L),
                sp.getString("keyword", "抢单")
        });
        return c;
    }

    @Override public String getType(Uri uri) { return "vnd.android.cursor.item/fngrab-cfg"; }
    @Override public Uri insert(Uri uri, ContentValues v) { return null; }
    @Override public int delete(Uri uri, String s, String[] a) { return 0; }
    @Override public int update(Uri uri, ContentValues v, String s, String[] a) { return 0; }
}
