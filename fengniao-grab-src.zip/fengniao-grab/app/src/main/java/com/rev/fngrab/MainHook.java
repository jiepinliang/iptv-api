package com.rev.fngrab;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 蜂鸟众包自动抢单。
 * 原理：不依赖内部接口签名，只盯列表刷新事件 + 遍历当前界面找「抢单」按钮点击。
 * 这样即使 App 升级改了类名，只要按钮还在就能用。
 */
public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "FNGrab";
    private static final String TARGET = "me.ele.crowdsource";

    private static volatile boolean enabled = true;
    private static volatile long minInterval = 300;
    private static volatile String keyword = "抢单";

    private static volatile Activity currentActivity;
    private static volatile long lastClick = 0;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (!TARGET.equals(lp.packageName)) return;
        XposedBridge.log(TAG + ": 进入 " + lp.packageName + " process=" + lp.processName);

        readPrefs(lp.classLoader);

        // 1) 记录当前前台 Activity（用于找按钮）
        XposedHelpers.findAndHookMethod(Activity.class, "onResume", new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam param) {
                currentActivity = (Activity) param.thisObject;
                XposedBridge.log(TAG + ": onResume " + currentActivity.getClass().getName());
            }
        });

        // 2) 盯「抢单大厅列表刷新」——蜂鸟内部有专门的刷新通知
        hookNotify(lp.classLoader, "me.ele.hb.biz.order.notify.LPDRefreshGrabOrderListNotification");
        hookNotify(lp.classLoader, "me.ele.hb.biz.order.notify.LPDEnableSlideGrabOrderNotification");

        // 3) 兜底：网络层看到抢单大厅接口返回，就触发一次扫描
        hookNetwork(lp.classLoader);

        // 4) 开启轮询兜底（某些版本没有通知）
        Thread t = new Thread(new Runnable() {
            @Override public void run() {
                while (true) {
                    try {
                        Thread.sleep(Math.max(120, minInterval));
                        if (enabled) scanAndClick();
                    } catch (Throwable ignore) { }
                }
            }
        }, "fngrab-poll");
        t.setDaemon(true);
        t.start();
    }

    private void readPrefs(ClassLoader cl) {
        // 完全离线：从本模块的 ContentProvider 读配置，不联网、不依赖授权服务器
        try {
            Class<?> helper = XposedHelpers.findClass("android.app.AndroidAppHelper", cl);
            Object app = XposedHelpers.callStaticMethod(helper, "currentApplication");
            if (app == null) return;
            Object resolver = XposedHelpers.callMethod(app, "getContentResolver");
            android.database.Cursor c = (android.database.Cursor)
                    XposedHelpers.callMethod(resolver, "query",
                            android.net.Uri.parse("content://com.rev.fngrab.cfg"),
                            null, null, null, null);
            if (c != null && c.moveToFirst()) {
                enabled = c.getInt(0) == 1;
                minInterval = c.getLong(1);
                keyword = c.getString(2);
                c.close();
            }
            XposedBridge.log(TAG + ": 配置 enable=" + enabled + " interval=" + minInterval + " keyword=" + keyword);
        } catch (Throwable e) {
            XposedBridge.log(TAG + ": 读配置失败，用默认值 " + e);
        }
    }

    private void hookNotify(ClassLoader cl, String cls) {
        try {
            Class<?> c = XposedHelpers.findClass(cls, cl);
            XposedBridge.hookAllMethods(c, "onReceive", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    if (enabled) scanAndClick();
                }
            });
            XposedBridge.log(TAG + ": 已挂刷新通知 " + cls);
        } catch (Throwable e) {
            XposedBridge.log(TAG + ": 无此通知 " + cls);
        }
    }

    private void hookNetwork(ClassLoader cl) {
        // 抢单大厅接口：/lpd_cs.delivery_query/v2/crowd/grab_center_orders
        try {
            Class<?> net = XposedHelpers.findClass("me.ele.hb.network.HBNetworkUtil", cl);
            XposedBridge.hookAllMethods(net, "parse", new XC_MethodHook() { });
            XposedBridge.log(TAG + ": 网络层 hook 尝试完成");
        } catch (Throwable e) {
            XposedBridge.log(TAG + ": 网络层 hook 跳过（类名不匹配）");
        }
    }

    /** 遍历当前界面，找可点击的「抢单」按钮并点击 */
    private void scanAndClick() {
        Activity act = currentActivity;
        if (act == null) return;
        long now = SystemClock.uptimeMillis();
        if (now - lastClick < minInterval) return;

        try {
            View root = act.getWindow().getDecorView();
            List<View> hits = new ArrayList<>();
            ArrayDeque<View> q = new ArrayDeque<>();
            q.add(root);
            while (!q.isEmpty() && hits.size() < 3) {
                View v = q.poll();
                if (v == null) continue;
                if (v instanceof TextView) {
                    CharSequence txt = ((TextView) v).getText();
                    if (txt != null && txt.toString().contains(keyword) && v.isShown()) {
                        hits.add(v);
                    }
                }
                if (v instanceof ViewGroup) {
                    ViewGroup g = (ViewGroup) v;
                    for (int i = 0; i < g.getChildCount(); i++) q.add(g.getChildAt(i));
                }
            }
            for (View v : hits) {
                View clickable = findClickable(v);
                if (clickable != null) {
                    lastClick = now;
                    XposedBridge.log(TAG + ": 点击抢单 -> " + clickable.getClass().getName());
                    clickable.performClick();
                    return;
                }
            }
        } catch (Throwable e) {
            XposedBridge.log(TAG + ": 扫描异常 " + e);
        }
    }

    private View findClickable(View v) {
        View p = v;
        for (int i = 0; i < 6 && p != null; i++) {
            if (p.isClickable()) return p;
            p = (p.getParent() instanceof View) ? (View) p.getParent() : null;
        }
        return v;
    }
}
