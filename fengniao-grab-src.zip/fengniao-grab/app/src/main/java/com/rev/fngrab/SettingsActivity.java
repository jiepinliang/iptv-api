package com.rev.fngrab;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Switch;

public class SettingsActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_settings);
        SharedPreferences sp = getSharedPreferences("cfg", MODE_PRIVATE);
        Switch sw = findViewById(R.id.sw_enable);
        EditText et1 = findViewById(R.id.et_interval);
        EditText et2 = findViewById(R.id.et_keyword);
        sw.setChecked(sp.getBoolean("enable", true));
        et1.setText(String.valueOf(sp.getLong("interval", 300)));
        et2.setText(sp.getString("keyword", "抢单"));
        sw.setOnCheckedChangeListener((v, c) -> sp.edit().putBoolean("enable", c).apply());
        et1.setOnFocusChangeListener((v, f) -> {
            if (!f) try { sp.edit().putLong("interval", Long.parseLong(et1.getText().toString())).apply(); } catch (Exception ignored) {}
        });
        et2.setOnFocusChangeListener((v, f) -> {
            if (!f) sp.edit().putString("keyword", et2.getText().toString()).apply();
        });
    }
}
