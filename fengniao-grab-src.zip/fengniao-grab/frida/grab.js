// 蜂鸟众包自动抢单 — Frida 版（无需编译，直接跑）
// 用法: frida -H 127.0.0.1:27043 -f me.ele.crowdsource -l grab.js
var KEYWORD = "抢单";
var INTERVAL = 300;
var lastClick = 0;
var currentActivity = null;

Java.perform(function () {
  var Activity = Java.use("android.app.Activity");
  Activity.onResume.implementation = function () {
    this.onResume();
    currentActivity = this;
    console.log("[FNGrab] onResume " + this.getClass().getName());
  };

  setInterval(function () {
    try { scanAndClick(); } catch (e) { }
  }, INTERVAL);
  console.log("[FNGrab] 已启动，关键字=" + KEYWORD);
});

function scanAndClick() {
  var act = currentActivity;
  if (act === null) return;
  var now = Date.now();
  if (now - lastClick < INTERVAL) return;

  Java.perform(function () {
    var View = Java.use("android.view.View");
    var ViewGroup = Java.use("android.view.ViewGroup");
    var TextView = Java.use("android.widget.TextView");

    var root = act.getWindow().getDecorView();
    var queue = [root];
    var hits = [];
    while (queue.length > 0 && hits.length < 3) {
      var v = queue.shift();
      if (v === null) continue;
      if (TextView.class.isInstance(v)) {
        var t = TextView.cast(v).getText();
        if (t !== null && t.toString().indexOf(KEYWORD) >= 0 && v.isShown()) hits.push(v);
      }
      if (ViewGroup.class.isInstance(v)) {
        var g = ViewGroup.cast(v);
        for (var i = 0; i < g.getChildCount(); i++) queue.push(g.getChildAt(i));
      }
    }
    for (var k = 0; k < hits.length; k++) {
      var p = hits[k];
      for (var n = 0; n < 6 && p !== null; n++) {
        if (p.isClickable()) break;
        var par = p.getParent();
        p = (par !== null && View.class.isInstance(par)) ? View.cast(par) : null;
      }
      if (p !== null && p.isClickable()) {
        lastClick = now;
        console.log("[FNGrab] click " + p.getClass().getName() + "  text=" + hits[k]);
        p.performClick();
        return;
      }
    }
  });
}
